
<?php
     session_start();    
          $db = new PDO("mysql:host=remotemysql.com;dbname=7MCjsuPWsg","7MCjsuPWsg","R0dA8fp0YX");
          $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_OBJ);    
     
?>